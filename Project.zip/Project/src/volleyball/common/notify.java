package volleyball.common;
/*
 * Comp 3716 A3 
 * 
 * Written on Nov 7 2016
 * by @RyanLey
 */

public class notify {
	public notify(schedule s){
		//email schedule to appropriate account(coaches,referees, etc.
	}
	public notify(String message, coach c){
		//notify the coach via email from account
	}
}

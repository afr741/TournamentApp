package volleyball.common;
/*
 * Comp 3716 A3 
 * 
 * Written on Nov 7 2016
 * by @RyanLey
 */
public class spectator extends account {
	public static String name="Spectator";
	public String email; 

	public spectator(String e){
		super(name,e);
	}
}
